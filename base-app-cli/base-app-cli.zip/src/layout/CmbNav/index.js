import CmbNav from './src/index.vue'

export default CmbNav
