import page from './src'
export default page
