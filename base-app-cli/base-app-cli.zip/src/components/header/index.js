import page from './src/header.vue'
export default page
