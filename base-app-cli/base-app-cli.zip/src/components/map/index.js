import MapPage from './src/index.vue'
export default MapPage
