import page from './src/myForm.vue'
export default page
