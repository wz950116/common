export { default } from './src/FieldPicker.vue'
